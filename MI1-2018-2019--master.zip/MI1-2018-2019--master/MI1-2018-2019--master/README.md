# MI1-2018-2019-
Portfolio van Mobile en Internet 1, 1TI ODISEE 2018-2019
